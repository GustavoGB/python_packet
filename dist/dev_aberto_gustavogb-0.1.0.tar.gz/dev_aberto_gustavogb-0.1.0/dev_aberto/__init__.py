from /scripts/hello.py import hello
